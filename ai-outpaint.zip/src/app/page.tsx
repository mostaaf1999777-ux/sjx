'use client';
import React, { useRef, useState } from 'react';

type SizeOption = '1024x1024' | '1536x1024' | '1024x1536';

type ExpandMode =
  | 'CENTER'
  | 'LEFT'
  | 'RIGHT'
  | 'TOP'
  | 'BOTTOM';

const ALLOWED_SIZES: SizeOption[] = ['1024x1024', '1536x1024', '1024x1536'];

function parseSize(s: SizeOption) {
  const [w, h] = s.split('x').map(Number);
  return { w, h };
}

function drawFeatheredMask(
  ctx: CanvasRenderingContext2D,
  keepRect: { x: number; y: number; w: number; h: number },
  canvasW: number,
  canvasH: number,
  feather: number
) {
  ctx.clearRect(0, 0, canvasW, canvasH);
  ctx.fillStyle = 'rgba(0,0,0,1)';
  ctx.fillRect(0, 0, canvasW, canvasH);

  ctx.save();
  ctx.globalCompositeOperation = 'destination-out';
  ctx.shadowColor = 'black';
  ctx.shadowBlur = feather;
  ctx.fillStyle = 'rgba(0,0,0,1)';
  ctx.fillRect(keepRect.x, keepRect.y, keepRect.w, keepRect.h);
  ctx.restore();
}

function placeOriginal(
  mode: ExpandMode,
  targetW: number,
  targetH: number,
  imgW: number,
  imgH: number
) {
  let x = 0, y = 0;
  switch (mode) {
    case 'CENTER':
      x = Math.floor((targetW - imgW) / 2);
      y = Math.floor((targetH - imgH) / 2);
      break;
    case 'LEFT':
      x = targetW - imgW;
      y = Math.floor((targetH - imgH) / 2);
      break;
    case 'RIGHT':
      x = 0;
      y = Math.floor((targetH - imgH) / 2);
      break;
    case 'TOP':
      x = Math.floor((targetW - imgW) / 2);
      y = targetH - imgH;
      break;
    case 'BOTTOM':
      x = Math.floor((targetW - imgW) / 2);
      y = 0;
      break;
  }
  return { x, y };
}

export default function Page() {
  const [file, setFile] = useState<File | null>(null);
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<SizeOption>('1536x1024');
  const [mode, setMode] = useState<ExpandMode>('CENTER');
  const [feather, setFeather] = useState(24);
  const [busy, setBusy] = useState(false);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const imgRef = useRef<HTMLImageElement | null>(null);

  const onFile = (f: File) => {
    setFile(f);
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.onload = () => {
      imgRef.current = img;
    };
    img.src = url;
  };

  const createCanvasAndMask = async (): Promise<{ base: Blob; mask: Blob } | null> => {
    if (!imgRef.current) return null;
    const img = imgRef.current;

    const { w: targetW, h: targetH } = parseSize(size);

    const side = Math.min(img.width, img.height);
    const sx = Math.floor((img.width - side) / 2);
    const sy = Math.floor((img.height - side) / 2);

    const baseCanvas = document.createElement('canvas');
    baseCanvas.width = targetW;
    baseCanvas.height = targetH;
    const bctx = baseCanvas.getContext('2d')!;
    bctx.clearRect(0, 0, targetW, targetH);

    const imgSize = Math.min(targetW, targetH);
    const pos = placeOriginal(mode, targetW, targetH, imgSize, imgSize);

    bctx.drawImage(img, sx, sy, side, side, pos.x, pos.y, imgSize, imgSize);

    const maskCanvas = document.createElement('canvas');
    maskCanvas.width = targetW;
    maskCanvas.height = targetH;
    const mctx = maskCanvas.getContext('2d')!;
    drawFeatheredMask(mctx, { x: pos.x, y: pos.y, w: imgSize, h: imgSize }, targetW, targetH, feather);

    const base = await new Promise<Blob>((res) => baseCanvas.toBlob((b) => res(b!), 'image/png'));
    const mask = await new Promise<Blob>((res) => maskCanvas.toBlob((b) => res(b!), 'image/png'));
    return { base, mask };
  };

  const handleSubmit = async () => {
    try {
      setError(null);
      setResultUrl(null);
      if (!file) {
        setError('حمّل صورة أولاً');
        return;
      }
      if (!prompt.trim()) {
        setError('اكتب وصفًا بسيطًا للمشهد لنتائج أدق.');
        return;
      }

      const cm = await createCanvasAndMask();
      if (!cm) {
        setError('تعذّر تجهيز القناع.');
        return;
      }
      const form = new FormData();
      form.append('image', cm.base, 'base.png');
      form.append('mask', cm.mask, 'mask.png');
      form.append('prompt', prompt);
      form.append('size', size);

      setBusy(true);
      const res = await fetch('/api/outpaint', { method: 'POST', body: form });
      setBusy(false);

      if (!res.ok) {
        const t = await res.text();
        setError(`فشل الطلب: ${t}`);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setResultUrl(url);
    } catch (e: any) {
      setBusy(false);
      setError(e?.message || 'خطأ غير متوقع');
    }
  };

  return (
    <div className="min-h-screen">
      <div className="max-w-5xl mx-auto p-6 space-y-6">
        <header className="flex items-center justify-between">
          <h1 className="text-2xl md:text-3xl font-semibold">🖼️ تمديد الصور بالذكاء الاصطناعي</h1>
        </header>

        <section className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl shadow p-4 space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">الصورة الأصلية</label>
              <div className="border-2 border-dashed rounded-xl p-6 text-center">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => e.target.files && onFile(e.target.files[0])}
                />
                <p className="text-xs text-neutral-500 mt-2">الأفضل رفع صورة مربعة؛ إن لم تكن، سنقصّ مربعًا من المنتصف تلقائيًا.</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">حجم الناتج</label>
                <select
                  value={size}
                  onChange={(e) => setSize(e.target.value as SizeOption)}
                  className="w-full rounded-lg border p-2"
                >
                  {ALLOWED_SIZES.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
                <p className="text-xs text-neutral-500 mt-1">يدعم gpt-image-1: 1024x1024، 1536x1024، 1024x1536</p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">اتجاه التمديد</label>
                <select
                  value={mode}
                  onChange={(e) => setMode(e.target.value as ExpandMode)}
                  className="w-full rounded-lg border p-2"
                >
                  <option value="CENTER">حول الصورة (مستحسن)</option>
                  <option value="RIGHT">تمديد يمين</option>
                  <option value="LEFT">تمديد يسار</option>
                  <option value="TOP">تمديد للأعلى</option>
                  <option value="BOTTOM">تمديد للأسفل</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">نعومة الحواف (Feather)</label>
              <input
                type="range"
                min={0}
                max={64}
                value={feather}
                onChange={(e) => setFeather(Number(e.target.value))}
                className="w-full"
              />
              <div className="text-xs text-neutral-500">قيمة أعلى = دمج أنعم بين الأصل والمناطق المولدة</div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">وصف المشهد (Prompt)</label>
              <textarea
                className="w-full border rounded-lg p-2 min-h-[84px]"
                placeholder="مثال: غرفة نوم مودرن بإضاءة دافئة ونباتات داخلية"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              <p className="text-xs text-neutral-500 mt-1">اكتب وصفًا مختصرًا يوجّه التوليد في المساحات الجديدة فقط.</p>
            </div>

            <button
              onClick={handleSubmit}
              disabled={busy || !file}
              className={`w-full rounded-xl py-3 font-medium ${busy || !file ? 'bg-neutral-300' : 'bg-black text-white hover:opacity-90'}`}
            >
              {busy ? 'جاري التوليد…' : 'مدّد الصورة'}
            </button>

            {error && (
              <div className="text-sm text-red-600">{error}</div>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow p-4">
            <h3 className="text-sm font-medium mb-2">المعاينة</h3>
            <div className="aspect-video bg-neutral-100 rounded-xl flex items-center justify-center overflow-hidden">
              {resultUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={resultUrl} alt="result" className="w-full h-auto" />
              ) : file ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={URL.createObjectURL(file)} alt="preview" className="h-full" />
              ) : (
                <div className="text-neutral-400 text-sm">لا توجد نتيجة بعد</div>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
