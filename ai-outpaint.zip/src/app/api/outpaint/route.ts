import { NextRequest } from 'next/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return new Response('Missing OPENAI_API_KEY', { status: 500 });
    }

    const form = await req.formData();
    const image = form.get('image') as File | null;
    const mask = form.get('mask') as File | null;
    const prompt = (form.get('prompt') as string) || '';
    const size = (form.get('size') as string) || '1536x1024';

    if (!image || !mask) {
      return new Response('image/mask missing', { status: 400 });
    }

    const upstream = new FormData();
    upstream.append('model', 'gpt-image-1');
    upstream.append('prompt', prompt);
    upstream.append('size', size);
    upstream.append('image', image, 'base.png');
    upstream.append('mask', mask, 'mask.png');
    upstream.append('response_format', 'b64_json');

    const res = await fetch('https://api.openai.com/v1/images/edits', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}` },
      body: upstream,
    });

    if (!res.ok) {
      const text = await res.text();
      return new Response(text, { status: res.status });
    }

    const json = await res.json();
    const b64 = json?.data?.[0]?.b64_json as string | undefined;
    if (!b64) {
      return new Response('No image returned', { status: 502 });
    }

    const buf = Buffer.from(b64, 'base64');
    return new Response(buf, {
      status: 200,
      headers: {
        'Content-Type': 'image/png',
        'Cache-Control': 'no-store',
      },
    });
  } catch (e: any) {
    return new Response(e?.message || 'Server error', { status: 500 });
  }
}
